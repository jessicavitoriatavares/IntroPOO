﻿Quadrado q1 = new Quadrado(10.0);
Console.WriteLine(q1.Lado);
q1.Lado = 8.0;
Console.WriteLine(q1.Area);
Console.WriteLine(q1.Perimetro);

Console.WriteLine("Separando");

Retangulo r1 = new Retangulo(10, 10);
Console.WriteLine(r1.Base);
Console.WriteLine(r1.Altura);
Console.WriteLine(r1.Perimetro);
Console.WriteLine(r1.Area);